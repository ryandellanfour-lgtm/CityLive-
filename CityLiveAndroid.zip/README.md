# City Live — Android MVP

This is the first Android prototype for the City Live app.

Current features:
- Choose a city
- City-specific live-style feed
- Post comments locally in the app
- Change cities
- Basic clean mobile interface

Next development step:
Connect the comment feed to Firebase Firestore so multiple phones can see new comments in real time.
